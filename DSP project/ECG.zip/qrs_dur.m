function QRS_duration=qrs_dur(ecg5,R_loc,fs)
flag=0;
filtered_signal = MA(ecg5', 5);
x=diff(filtered_signal);
filtered_signal(find(abs(x)<10^(-1.5)))=0;
for i=1:length(filtered_signal)
 if filtered_signal(i)~=0
     flag=flag+1;
 end
end
QRS_duration=(flag/(2*length(R_loc)))/fs;