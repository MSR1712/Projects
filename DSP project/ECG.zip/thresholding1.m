function[Q_val,Q_loc,R_val,R_loc,S_val,S_loc,TH,w]=thresholding1(ecg,ecg5)
% %% Thresholding operation %%
TH = mean(ecg5)*max(ecg5); % Set threshold
w=(ecg5>(TH));

x=find(diff([0 w']) == 1); % Finding location of 0 to 1 transition
y=find(diff([w' 0]) == -1); % Finding location of 1 to 0 transition

%% cancelling the delay due to LOW PASS FILTER and HIGH PASS FILTER %%
x=x-(6+16); % 6 DELAY BY LPF & 16 DELAY BY HPF
y=y-(6+16);

%% Detect Q,R,S points %%
for i=1:length(x)
    %% R Locations %%
    [R_val(i),R_loc(i)]=max(ecg(x(i):y(i)));
    R_loc(i) = R_loc(i)-1 + x(i); % adding offset
end
% [Rpeaks,locs]=findpeaks(ECG_filtered);
% threshold=2*rms(ECG_filtered);
% Rwave=Rpeaks>threshold;
% Rwaveform=zeros(size(ECG_filtered));
% Rwaveform(locs(Rwave))=max(ECG_filtered);
% 
% 
% DETECTION OF R PEAK AND CORRESPONDING LOCATIONS

j=1;
% for i=1:length(R_val)
%     if(Rwaveform(i)~=0)
%      R_peaks(j)=ECG_filtered(i); % compression of Rpeaks into R_peaks by eleminating the extra 0]
%      R_locs(j)=i;
%      j=j+1;
%     end
% end

% DETECTION OF S PEAK AND CORRSPONDING LOCATIONS
%  ecg=moving_average_filter(ecg, 5)
j=1;
for i=1:length(R_loc)
    m=R_val(i);
    n=ecg(R_loc(i)+j);
    while 1
        j=j+1;
        if n>=m
            S_val(i)=m;              %[last e jno jamela na hoi]
            S_loc(i)=j+R_loc(i)-2;
            break
        elseif j+R_loc(i)>length(ecg)
              break
        else
            m=n;
            n=ecg(j+R_loc(i));
        end
    end
j=1;
end

% DETECTION OF Q PEAK AND CORRESPONDING LOCATIONS
j=1;
for i=1:length(R_loc)
    m=R_val(i);
    n=ecg(R_loc(i)-j);
    while 1
        j=j+1;
        if n>=m
            Q_val(i)=m;
            Q_loc(i)=-j+R_loc(i)+2;
            break
        else
            m=n;
            n=ecg(-j+R_loc(i));
        end
    end
j=1;
end
if length(Q_loc)~=length(S_loc)
    Q_loc(length(Q_loc))=0;
    S_loc(length(Q_loc))=0;
end
    
%     %% Q Locations %%
%     [Q_val(i),Q_loc(i)]=min(ecg(R_loc(i):-1:R_loc(i)-8));
%     Q_loc(i) = R_loc(i)-Q_loc(i)+1; % adding offset
%     
%     
%     %% S Locations %%
%     [S_val(i),S_loc(i)]=min(ecg(R_loc(i):R_loc(i)+10));
%     S_loc(i) = R_loc(i)+S_loc(i)-1; % adding offset
% end
% 
