clc;
clear;
close all;

% Load an ECG signal from a file selected by the user
[filename, pathname] = uigetfile('.', 'Select the signal');
filewithpath = strcat(pathname, filename);
ecg1 = load(filewithpath);
ecg = ecg1.val;
ecg=ecg-mean(ecg);
ecg=ecg/max(abs(ecg));
fs=length(ecg)/10;
slen=length(ecg);
t=(1:slen)/fs;
P1=subplot(6,1,1);
plot(t,ecg);
xlim([0,10]);
grid on;
grid minor;
xlabel('Time (seconds)')
ylabel('Signal Amplitude');
title('Original ECG Signal');

%% Bandpass filtering %%
ecg_out2=bandpass_filtering(ecg);
P2=subplot(6,1,2);
plot(t,ecg_out2);
xlim([0,10]);
grid on;
grid minor;
xlabel('Time (seconds)')
ylabel('Signal Amplitude');
title('BPF Block Output');
%% Derivative Operation %%
ecg_out3=differentiator(ecg_out2);
P3=subplot(6,1,3);
plot(t,ecg_out3);
xlim([0,10]);
grid on;
grid minor;
xlabel('Time (seconds)')
ylabel('Signal Amplitude');
title('Derivative Block Output');
%% squaring operation %%
ecg_out4=squaring(ecg_out3);
P4=subplot(6,1,4);
plot(t,ecg_out4);
xlim([0,10]);
grid on;
grid minor;
xlabel('Time (seconds)')
ylabel('Signal Amplitude');
title('Squaring Block Output');

%% Integration operation %%
ecg5=integration(ecg_out4);
P5=subplot(6,1,5);
plot(t,ecg5);
xlim([0,10]);
grid on;
grid minor;
hold on;
xlabel('Time (seconds)')
ylabel('Signal Amplitude');
title('Integration Block Output');

%% Thresholding operation %%
[Q_val,Q_loc,R_val,R_loc,S_val,S_loc,TH,w]=thresholding1(ecg_out2,ecg5);
% P6=subplot(6,1,6);
figure

plot(t,ecg_out2);
xlim([0,10]);
grid on;
grid minor;
hold on;
plot(t(Q_loc),Q_val,'bo');
plot(t(R_loc),R_val,'r*');
plot(t(S_loc),S_val,'go');
xlabel('Time (seconds)')
ylabel('Signal Amplitude');
title('ECG Signal with QRS Locations after Thresholding');
legend('ECG','Q','R','S');
hold off;


%% Calculation of Heart Rate and QRS Duration %%
HT=heart_rate(R_loc,t);
disp(['Heart Rate for ecg = ' num2str(HT) ' beats/min']);
% set(handles.edit1,'string',dur); % Display QRS Duration
% disp(['QRS Duration for ecg = ' num2str(dur) ' sec']);


QRS_duration=qrs_dur(ecg5,R_loc,fs);
disp(['QRS duration = ' num2str(QRS_duration) 'seconds'])




