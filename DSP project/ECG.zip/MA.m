
function filteredsignal =MA(x,M)

z=zeros(1,length(x));

for i=1:M-1
    z(i)=M*x(i);
end

for i= M:length(x)
    
    for j=0:M-1
    z(i)=z(i)+x(i-j);
    end
   
end
 filteredsignal =z/M;

end 